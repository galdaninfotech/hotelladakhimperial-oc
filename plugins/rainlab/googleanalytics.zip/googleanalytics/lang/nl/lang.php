<?php

return [
    'widgets' => [
        'title_browsers' => 'Browsers',
        'description_browsers' => 'Toont een overzicht van browsers die bezoekers gebruiker om je website te bezoeken.',
        'title_toppages' => 'Top Pagina\'s',
        'noresult_toppages' => 'Er zijn geen paginaweergaves voor de ingestelde interval',
        'title_traffic_goal' => 'Doelen',
        'title_traffic_overview' => 'Overzicht verkeer',
        'title_traffic_sources' => 'Verwijzende sites',
        'description_traffic_sources' => 'Toont verwijzende sites die een link hebben naar je website.',
    ],
    'strings' => [
        'page_url' => 'Pagina URL',
        'pageviews' => 'Paginaweergaves',
        'current' => 'Huidig',
        'goal' => 'Goal'
    ],
];